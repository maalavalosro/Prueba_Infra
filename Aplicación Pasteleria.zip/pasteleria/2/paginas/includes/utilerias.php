<?php

    function redireccionar ($mensaje, $dir) {
        include('includes/encabezado.php');
        echo '<div class = "formulario-div" style="color:brown">';
        echo '<h1 style = "text-align:center">' . $mensaje . '</h1>';
        echo '<h4 style = "text-align:center"> Redireccionando... </h4>';
        echo '</div>';
        include('includes/pie.php');
        header('refresh:3,url=' . $dir);
    }

?>